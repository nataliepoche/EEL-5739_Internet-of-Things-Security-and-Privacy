#ifndef TEST_CERT_DEF_2_DEVICE_CSR_H
#define TEST_CERT_DEF_2_DEVICE_CSR_H

#include "atcacert/atcacert_def.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const atcacert_def_t g_csr_def_2_device;

#ifdef __cplusplus
}
#endif

#endif
